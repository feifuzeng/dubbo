The images in this directory are used if the current skin lacks them.
